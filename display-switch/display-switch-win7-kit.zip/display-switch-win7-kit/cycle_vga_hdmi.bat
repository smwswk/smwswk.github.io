@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set MONITOR_ID=TFC0238

echo Cycling monitor input between VGA value 1 and HDMI value 3.
ControlMyMonitor.exe /SwitchValue %MONITOR_ID% 60 1 3
echo Done. Exit code: %ERRORLEVEL%
