Display switch kit for Win7 + Mac sharing one monitor

Use case:
  One Win7 PC on VGA and one Mac on HDMI share the same monitor.
  The Win7 PC sends DDC/CI input-source commands, and AutoHotkey binds Win+C.

Verified setup:
  Monitor: TF2416
  Win7 adapter: Intel(R) HD Graphics Family
  TF2416 input values:
    VGA / Win7 = 1
    HDMI / Mac = 3

Quick start on Win7:
  1. Copy the whole display-switch-win7-kit folder to the Win7 PC.
  2. Run diagnose_monitor.bat and check that VCP 60 / Input Select exists.
  3. Run switch_to_mac_hdmi.bat to test switching to Mac.
  4. Manually switch back to Win7.
  5. Run start_win_c_hotkey.bat.
  6. Press Win+C to toggle between Win7/VGA and Mac/HDMI.

Hotkeys:
  Win+C        toggle Win7/VGA and Mac/HDMI
  Win+Shift+C switch directly to Mac/HDMI
  Win+Ctrl+C  switch directly to Win7/VGA

Start automatically after Win7 login:
  Run install_win_c_hotkey_on_startup.bat

Remove:
  Run uninstall_hotkey_from_startup.bat

If the monitor is not TF2416:
  Run diagnose_monitor.bat first.
  Check VCP 60 / Input Select possible values.
  Edit switch_to_mac_hdmi.bat, switch_to_win7_vga.bat, and cycle_vga_hdmi.bat.

Bundled tools:
  ControlMyMonitor.exe from NirSoft for DDC/CI.
  AutoHotkeyU32.exe from AutoHotkey v1.1.37.02 portable for Win+C.
