Display switch toolkit for TF2416

Folder on Win7:
  C:\Users\admin\Documents\Scanned Documents\display_switch

Folder on Mac:
  /Volumes/ScannedDocuments/display_switch

Main idea:
  Mac-side DDC failed on the current HDMI path.
  This package lets Win7 send the DDC input-switch command instead.

Files:
  diagnose_monitor.bat
    Run this first on Win7. It writes monitor details to monitors.txt,
    vcp_tf2416.tsv, and input_current.txt.

  switch_to_mac_hdmi.bat
    Run on Win7 to switch the monitor to HDMI/Mac.
    TF2416 diagnosis value: 3.

  switch_to_win7_vga.bat
    Run on Win7 to switch the monitor to VGA/Win7.
    Default VGA input value: 1.

  cycle_vga_hdmi.bat
    Run on Win7 to toggle VCP 60 between VGA value 1 and HDMI value 3.

  start_watcher_now.bat
    Starts a background watcher on Win7 for this login session.

  start_hotkey_now.bat
    Starts AutoHotkey listener for this login session.
    Win+C toggles the monitor between VGA/Win7 and HDMI/Mac.
    Win+Shift+C switches directly to HDMI/Mac.
    Win+Ctrl+C switches directly to VGA/Win7.

  install_hotkey_on_startup.bat
    Adds the Win+C hotkey listener to the Win7 Startup folder.

  uninstall_hotkey_from_startup.bat
    Removes the Startup entry and stops the hotkey listener.

  install_watcher_on_startup.bat
    Adds the watcher to the Win7 Startup folder.

  uninstall_watcher_from_startup.bat
    Removes the Startup entry.

  watch_display_switch.bat
    Watches for trigger files:
      to_win7.flag -> switch monitor to VGA
      to_mac.flag  -> switch monitor to HDMI

  trigger_win7_from_mac.command
    Double-click on Mac to create to_win7.flag, then sleep the Mac display.
    This requires the Win7 watcher to be running.

TF2416 VCP 60 input values from diagnosis:
  1 = VGA/Win7
  3 = HDMI/Mac

Common VCP 60 input values on other monitors:
  1  = VGA-1 / Analog-1
  17 = HDMI-1
  18 = HDMI-2
  15 = DisplayPort-1
  16 = DisplayPort-2

If switching fails:
  1. Open the monitor OSD menu and enable DDC/CI.
  2. Run diagnose_monitor.bat on Win7.
  3. Check vcp_tf2416.tsv for VCP Code 60 / Input Select.
  4. If HDMI/VGA values are different, edit the BAT files.
  5. If Win7 also cannot read VCP 60, software switching is blocked by
     the monitor/cable/GPU path. Use the monitor button or a hardware KVM.
