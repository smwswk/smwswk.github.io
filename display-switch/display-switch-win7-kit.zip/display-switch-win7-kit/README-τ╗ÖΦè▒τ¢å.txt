双机共用显示器切换包

用途：
  一台 Win7 老电脑 + 一台 Mac 共用同一台显示器。
  Win7 端通过 DDC/CI 主动切换显示器输入源，并用 Win+C 做快捷键。

已验证环境：
  显示器：TF2416
  Win7 显卡：Intel(R) HD Graphics Family
  TF2416 输入源值：
    VGA / Win7 = 1
    HDMI / Mac = 3

快速使用：
  1. 把整个 display-switch-win7-kit 文件夹放到 Win7 电脑。
  2. 双击 diagnose_monitor.bat，确认能看到 VCP 60 / Input Select。
  3. 双击 switch_to_mac_hdmi.bat，测试能否切到 Mac。
  4. 手动切回 Win7 后，双击 start_win_c_hotkey.bat。
  5. 之后按 Win+C，在 Win7/VGA 和 Mac/HDMI 之间切换。

快捷键：
  Win+C        在 Win7/VGA 和 Mac/HDMI 之间切换
  Win+Shift+C  直接切到 Mac/HDMI
  Win+Ctrl+C   直接切到 Win7/VGA

开机自动启动：
  双击 install_win_c_hotkey_on_startup.bat

卸载：
  双击 uninstall_hotkey_from_startup.bat

如果不是 TF2416：
  先运行 diagnose_monitor.bat。
  打开生成的 vcp_tf2416.tsv 或 vcp_primary.tsv，看 VCP 60 / Input Select 的 Possible Values。
  再修改 switch_to_mac_hdmi.bat、switch_to_win7_vga.bat、cycle_vga_hdmi.bat 里的输入源值。

依赖：
  ControlMyMonitor.exe：NirSoft DDC/CI 工具。
  AutoHotkeyU32.exe：AutoHotkey v1.1 32-bit 免安装版，用于监听 Win+C。
