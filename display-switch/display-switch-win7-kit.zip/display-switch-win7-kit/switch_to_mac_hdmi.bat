@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set MONITOR_ID=TFC0238
set HDMI_INPUT=3

echo Switching monitor to HDMI/Mac. VCP 60 value: %HDMI_INPUT%
ControlMyMonitor.exe /SetValue %MONITOR_ID% 60 %HDMI_INPUT%
echo Done. Exit code: %ERRORLEVEL%
