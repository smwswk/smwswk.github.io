@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set VGA_INPUT=1
set MONITOR_ID=TFC0238

echo Switching monitor to VGA/Win7. VCP 60 value: %VGA_INPUT%
ControlMyMonitor.exe /SetValue %MONITOR_ID% 60 %VGA_INPUT%
echo Done. Exit code: %ERRORLEVEL%
