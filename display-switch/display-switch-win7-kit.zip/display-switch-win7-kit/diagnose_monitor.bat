@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo Running ControlMyMonitor diagnosis...
echo Output folder: %CD%

ControlMyMonitor.exe /smonitors "%~dp0monitors.txt"
ControlMyMonitor.exe /stab "%~dp0vcp_tf2416.tsv" TFC0238
ControlMyMonitor.exe /GetValue TFC0238 60 >"%~dp0input_current.txt"

echo.
echo Done.
echo Wrote:
echo   monitors.txt
echo   vcp_tf2416.tsv
echo   input_current.txt
echo.
pause
